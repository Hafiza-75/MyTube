from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def home(request):
    return HttpResponse("""
        <h1>📺 Welcome to MyTube</h1>
        <p>Watch, share and enjoy videos online!</p>
        <iframe width="400" height="200" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameborder="0" allowfullscreen></iframe>
    """)

def videos(request):
    return HttpResponse("""
        <h2>🎬 Video List</h2>
        <ul>
            <li>How to Learn Python – 10 min</li>
            <li>HTML Basics – 15 min</li>
            <li>Django Crash Course – 20 min</li>
        </ul>
    """)

def upload(request):
    return HttpResponse("""
        <h2>📤 Upload Video</h2>
        <p>Coming Soon: Upload your own videos and share with the world.</p>
    """)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),
    path('videos/', videos),
    path('upload/', upload),
]
